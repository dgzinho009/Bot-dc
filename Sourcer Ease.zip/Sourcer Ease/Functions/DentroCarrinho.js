
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, AttachmentBuilder } = require("discord.js")
const { produtos, carrinhos, pagamentos, configuracao } = require("../DataBaseJson")
const { QuickDB } = require("quick.db");
const mercadopago = require("mercadopago");
const moment = require("moment");
const db = new QuickDB();


async function DentroCarrinhoPix(interaction, client) {
    interaction.deferUpdate();
    await interaction.message.edit({ content: `🔄 Aguarde...`, ephemeral: true, components: [] }).then(async tt => {
        const yy = await carrinhos.get(interaction.channel.id);
        const hhhh = produtos.get(`${yy.infos.produto}.Campos`);
        const gggaaa = hhhh.find(campo22 => campo22.Nome === yy.infos.campo);

        let valor = 0;

        if (yy.cupomadicionado !== undefined) {
            const valor2 = gggaaa.valor * yy.quantidadeselecionada;
            const hhhh2 = produtos.get(`${yy.infos.produto}.Cupom`);
            const gggaaaawdwadwa = hhhh2.find(campo22 => campo22.Nome === yy.cupomadicionado);
            valor = valor2 * (1 - gggaaaawdwadwa.desconto / 100);
        } else {
            valor = gggaaa.valor * yy.quantidadeselecionada;
        }

        const aaaa = Number(valor).toFixed(2);

        var agora = new Date();
        agora.setMinutes(agora.getMinutes() + 10);
        agora.setMinutes(agora.getMinutes() - agora.getTimezoneOffset() + 240);
        agora.setHours(agora.getHours() - 5);
        var novaDataFormatada = agora.toISOString().replace('Z', '-04:00');

        var payment_data = {
            transaction_amount: Number(aaaa),
            description: `Pagamento - ${interaction.user.username}`,
            date_of_expiration: moment().add(10, 'minutes').toDate(), // Use moment para definir a data de expiração
            payment_method_id: 'pix',
            payer: {
                email: `${interaction.user.id}@gmail.com`,
                first_name: 'Victor André',
                last_name: 'Ricardo Almeida',
                identification: {
                    type: 'CPF',
                    number: '15084299872'
                },
                address: {
                    zip_code: '86063190',
                    street_name: 'Rua Jácomo Piccinin',
                    street_number: '971',
                    neighborhood: 'Pinheiros',
                    city: 'Londrina',
                    federal_unit: 'PR'
                }
            }
        };

        mercadopago.configurations.setAccessToken(configuracao.get('pagamentos.MpAPI'));

        var preference = {
            items: [
                {
                    title: `Comprador: ${interaction.user.username}`,
                    unit_price: Number(aaaa),
                    quantity: 1
                }
            ],
            notification_url: interaction.guild.iconURL(),
            date_of_expiration: novaDataFormatada,
            payment_methods: {
                excluded_payment_methods: [
                    { id: 'pix' }
                ],
                installments: 1
            }
        };
        await mercadopago.payment.create(payment_data).then(async function (data) {
            const { qrGenerator } = require('../Lib/QRCodeLib');
            const qr = new qrGenerator({ imagePath: './Lib/aaaaa.png' });
            const qrcode = await qr.generate(data.body.point_of_interaction.transaction_data.qr_code);

            const buffer = Buffer.from(qrcode.response, 'base64');
            const attachment = new AttachmentBuilder(buffer, { name: 'payment.png' });

            const embed = new EmbedBuilder()
                .setColor(`${configuracao.get(`Cores.Principal`) == null ? '2b2d31' : configuracao.get('Cores.Principal')}`)
                .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                .setTitle('Pagamento via PIX criado')
                .addFields(
                    { name: 'Código copia e cola', value: `\`\`\`${data.body.point_of_interaction.transaction_data.qr_code}\`\`\`` }
                )
                .setFooter({ text: `${interaction.guild.name} - Pagamento expira em 10 minutos.` })
                .setTimestamp()
                .setImage('attachment://payment.png');

            const row3 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('codigocopiaecola')
                        .setLabel('Código copia e cola')
                        .setEmoji('1262557532686385244')
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId('deletchannel')
                        .setEmoji('1262295425935740981')
                        .setStyle(2)
                );

            embed.setImage('attachment://payment.png');

            carrinhos.set(`${interaction.channel.id}.pagamentos`, { id: data.body.id, cp: data.body.point_of_interaction.transaction_data.qr_code, method: 'pix' });
            pagamentos.set(`${interaction.channel.id}.pagamentos`, { id: data.body.id, cp: data.body.point_of_interaction.transaction_data.qr_code, method: 'pix', data: Date.now() });

            await tt.edit({ embeds: [embed], files: [attachment], content: '', components: [row3] });

            interaction.channel.setName(`💱・${yy.user.username}・${yy.user.id}`);

            setTimeout(async () => {
                // Deletar o canal de interação após o tempo de expiração
                await interaction.channel.delete();
            }, 600000); // 10 minutos em milissegundos






            })
            .catch(function (error) {
                const row3 = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("pagarpix")
                            .setLabel('Pagar com pix')
                            .setStyle(1),
                            new ButtonBuilder()
                            .setCustomId("voltarcarrinho")
                            .setEmoji(`1262295432130723842`)
                            .setStyle(2)
                    )

                tt.edit({ content: `Selecione uma forma de pagamento.`, ephemeral: true, components: [row3] })
                interaction.followUp({ content: `❌ | Ocorreu um erro ao criar o pagamento, tente novamente.\nErro: ${error}`, ephemeral: true })
            })

    })
}

function DentroCarrinho2(interaction) {

    const yd = carrinhos.get(interaction.channel.id)

    const hhhh = produtos.get(`${yd.infos.produto}.Campos`)
    const gggaaa = hhhh.find(campo22 => campo22.Nome === yd.infos.campo)


    if (yd.quantidadeselecionada > gggaaa.condicao?.valormaximo) return interaction.reply({ content: `❌| Você não pode comprar mais de \`${gggaaa.condicao.valormaximo}x ${yd.infos.produto} - ${yd.infos.campo}\``, ephemeral: true })
    if (yd.quantidadeselecionada < gggaaa.condicao?.valorminimo) return interaction.reply({ content: `❌| Você não pode comprar mais de \`${gggaaa.condicao.valorminimo}x ${yd.infos.produto} - ${yd.infos.campo}\``, ephemeral: true })
    interaction.deferUpdate()

    // content: `Selecione uma forma de pagamento.`


    const row3 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("pagarpix")
                .setLabel('Pagar com PIX')
                .setStyle(1),

            new ButtonBuilder()
                .setCustomId("voltarcarrinho")
                .setEmoji(`1262295432130723842`)
                .setStyle(2)
        )

    interaction.message.edit({ content: `Selecione uma forma de pagamento.`, components: [row3], embeds: [] })
}

async function DentroCarrinho1(thread, status) {

    let ggg
    if (status == 1) {
        ggg = carrinhos.get(thread.channel.id)
    } else {
        ggg = carrinhos.get(thread.id)
    }



    const hhhh = produtos.get(`${ggg.infos.produto}.Campos`)
    const gggaaa = hhhh.find(campo22 => campo22.Nome === ggg.infos.campo)
    let yy = await carrinhos.get(`${ggg.threadid}.quantidadeselecionada`)
    if (yy == null) {
        await carrinhos.set(`${ggg.threadid}.quantidadeselecionada`, 1)
        yy = 1
    }


    const embed = new EmbedBuilder()
        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
        .setAuthor({ name: ggg.user.username, iconURL: ggg.user.displayAvatarURL })
        .setTitle(`Finalizando Carrinho`)

        .setFooter(
            { text: ggg.guild.name }
        )
        .setTimestamp()


    const hhhhsdsadasd2 = produtos.get(`${ggg.infos.produto}.Config`)

    if (hhhhsdsadasd2.banner !== undefined || hhhhsdsadasd2.banner !== '') {
        try {
            await embed.setImage(`${hhhhsdsadasd2.banner}`)
        } catch (error) {

        }

    }
    if (hhhhsdsadasd2.icon !== undefined || hhhhsdsadasd2.icon !== '') {
        try {
            await embed.setThumbnail(`${hhhhsdsadasd2.icon}`)
        } catch (error) {

        }

    }



    if (ggg.cupomadicionado !== undefined) {


        const ggg2 = carrinhos.get(thread.channel.id)
        const hhhh2 = produtos.get(`${ggg.infos.produto}.Cupom`)
        const gggaaaawdwadwa = hhhh2.find(campo22 => campo22.Nome === ggg2.cupomadicionado)

        const yyfyfy = gggaaa.valor * yy

        const valorComDesconto = yyfyfy * (1 - gggaaaawdwadwa.desconto / 100);

        const valorOriginalFormatado = Number(yyfyfy).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        const valorComDescontoFormatado = Number(valorComDesconto).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });


        embed.addFields(
            { name: `**Carrinho**`, value: `\`${yy}x ${ggg.infos.produto} - ${ggg.infos.campo}\``, inline: true },
            {
                name: `**Valor à vista**`,
                value: `De ~~\`R$ ${valorOriginalFormatado}\`~~  por \`${valorComDescontoFormatado}\``,
                inline: true
            },
            { name: `**Cupom**`, value: `\`${ggg2.cupomadicionado}\``, inline: false },
            { name: `**Em estoque**`, value: `\`${gggaaa.estoque.length}\``, inline: false }
        )

    } else {

        const fields = [];

        if (gggaaa.desc) {
            fields.push({
                name: `**Descrição**`,
                value: `**${gggaaa.desc}**`,
                inline: false
            });
        }
        embed.addFields(...fields);
        embed.addFields(
            { name: `**Carrinho**`, value: `\`${yy}x ${ggg.infos.produto} - ${ggg.infos.campo}\``, inline: true },
            { name: `**Valor à vista**`, value: `\`R$ ${Number(gggaaa.valor * yy).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\``, inline: true },
            { name: `**Em estoque**`, value: `\`${gggaaa.estoque.length}\``, inline: false }
        )

        // Adiciona o campo de descrição apenas se gggaaa.desc não estiver vazio ou indefinido

    }

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("irparapagamento")
                .setLabel('Ir para pagamento')
                .setStyle(1),

            new ButtonBuilder()
                .setCustomId("editarquantidade")
                .setLabel('Editar quantidade')
                .setStyle(2),

            new ButtonBuilder()
                .setCustomId("usarcupom")
                .setLabel('Utilizar cupom')
                .setStyle(1),

            new ButtonBuilder()
                .setCustomId("deletchannel")
                .setEmoji(`1262295425935740981`)
                .setStyle(2)
        )

    if (status == 1) {
        thread.deferUpdate()
        thread.message.edit({ content: `<@${ggg.user.id}>`, embeds: [embed], components: [row2] })

    } else {
        thread.send({ content: `<@${ggg.user.id}>`, embeds: [embed], components: [row2] })
    }

}

module.exports = {
    DentroCarrinho1,
    DentroCarrinho2,
    DentroCarrinhoPix
}