const { ApplicationCommandType, ChannelType, PermissionFlagsBits, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");

async function CreateStore(interaction, valor) {

        const confirmEmbed = new EmbedBuilder()
            .setTitle(`Loja: ${interaction.guild.name}`)
            .setDescription("Este comando irá recriar o seu servidor, isto inclui apagar totalmente ele e o recriar como uma loja, tem certeza que deseja continuar?")
            .setImage(`https://media.discordapp.net/attachments/1258998310048501801/1259003597547372625/Convite_zeustm.jpg?ex=668eb738&is=668d65b8&hm=70b6536c8f221751923b229db2dbdc4005910f7f8e5613e5ac5529f1a4eebc7c&=&format=webp&width=1200&height=292`)
            .setColor("#000000");

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('confirm')
                    .setLabel('Sim')
                    .setEmoji(`1237422701338034348`)
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('cancel')
                    .setLabel('Não')
                    .setEmoji(`1246949731251519518`)
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({
            embeds: [confirmEmbed],
            components: [buttons],
            ephemeral: true
        });

        const filter = i => i.user.id === interaction.user.id;
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000, max: 1 });

        collector.on('collect', async i => {
            if (i.customId === 'confirm') {
                await i.update({ content: `🔄 | Aguarde um momento, estou recriando os canais e cargos...`, embeds: [], components: [], ephemeral: true });

                // Apagar todos os canais
                interaction.guild.channels.cache.forEach(channel => channel.delete().catch(() => {}));

                // Criação de cargos
                const createRole = async (name) => {
                    return await interaction.guild.roles.create({
                        name,
                        permissions: []
                    }).catch(() => false);
                };

                const role1 = await createRole("@Owner");
                const role2 = await createRole("@Adm");
                const role3 = await createRole("@Team");
                const role6 = await createRole("@Cliente");
                const role7 = await createRole("@Membro");

                if (!role1 || !role2 || !role3 || !role6 || !role7) {
                    return interaction.editReply({ content: `Não foi possível criar todos os cargos.`, ephemeral: true });
                }
                // call
                const categoryServerBy = await interaction.guild.channels.create({
                  name: "💎 - @Servidor:",
                  type: ChannelType.GuildCategory,
                  position: 3
              }).catch(() => false);
              if (!categoryServerBy) return interaction.editReply({ content: `Não tenho permissão de criar a categoria "Servidor BY:".`, ephemeral: true });

              await interaction.guild.channels.create({
                  name: ".gg/zeusofc",
                  type: ChannelType.GuildVoice,
                  parent: categoryServerBy.id
              }).catch(() => false);
                const createChannel = async (name, type, parent, permissionOverwrites, content) => {
                    const channel = await interaction.guild.channels.create({
                        name,
                        type,
                        parent,
                        permissionOverwrites
                    }).catch(() => false);
                    if (channel && content) {
                        await channel.send({ content }).catch(() => {});
                    }
                    return channel;
                };

                const categoryTerms = await interaction.guild.channels.create({
                  name: "🚨 - @INFOS",
                  type: ChannelType.GuildCategory,
                  position: 3
              }).catch(() => false);
              if (!categoryTerms) return interaction.editReply({ content: `Não tenho permissão de criar canais.`, ephemeral: true });

              const termsPermissions = [
                  { id: interaction.guild.id, allow: ["ViewChannel"], deny: ["SendMessages"] },
                  { id: interaction.client.user.id, allow: ["ViewChannel", "SendMessages"] },
                  { id: interaction.user.id, allow: ["ViewChannel", "SendMessages"] },
              ];

              await createChannel("📚・t3rms", ChannelType.GuildText, categoryTerms.id, termsPermissions, `**#Reembolso e Garantia:\n## \`1.\` Garantia de Produto:\nA garantia dos produtos está descrita em cada um deles.\n## \`2.\` Reembolso por Atraso na Entrega:\nO reembolso só é possível caso não haja entrega em até 3-4 dias após a compra.\n## \`3.\` Reembolso por Arrependimento:\nNão há reembolso por arrependimento. Certifique-se de sua compra antes de confirmá-la.\n#Geral:\n## \`1.\` Concordância com os Termos:\nAo comprar, o usuário concorda com os termos e condições estabelecidos neste documento.\n## \`2.\` Pressão sobre o Entregador:\nO usuário não pode apressar o entregador. Pedimos paciência durante o processo de entrega.\n**Agradecemos por escolher nossos serviços e estamos comprometidos em fornecer uma experiência positiva.**\n**Se tiver __dúvidas__, entre em contato com nossa __equipe de suporte__. Estamos aqui para ajudar!**`);
              await createChannel("📢・avisos", ChannelType.GuildText, categoryTerms.id, termsPermissions);
              await createChannel("🛍・entregas", ChannelType.GuildText, categoryTerms.id, termsPermissions);
              await createChannel("🎀・feedback", ChannelType.GuildText, categoryTerms.id, termsPermissions);

                const categoryMembers = await interaction.guild.channels.create({
                    name: "🛒 - @LOJA",
                    type: ChannelType.GuildCategory,
                    position: 3
                }).catch(() => false);
                if (!categoryMembers) return interaction.editReply({ content: `Não tenho permissão de criar canais.`, ephemeral: true });

                const productPermissions = [
                    { id: interaction.guild.id, allow: ["ViewChannel"], deny: ["SendMessages"] },
                    { id: interaction.client.user.id, allow: ["ViewChannel", "SendMessages"] },
                    { id: interaction.user.id, allow: ["ViewChannel", "SendMessages"] },
                ];

                for (let i = 1; i <= 6; i++) {
                    await createChannel(`🛒・pr0duto`, ChannelType.GuildText, categoryMembers.id, productPermissions, `**Canal de vendas**`);
                }

                const categoryStaff = await interaction.guild.channels.create({
                    name: "📡 - @LOGS",
                    type: ChannelType.GuildCategory,
                    position: 3
                }).catch(() => false);
                if (!categoryStaff) return interaction.editReply({ content: `Não tenho permissão de criar canais.`, ephemeral: true });

                const staffPermissions = [
                    { id: interaction.guild.id, deny: ["ViewChannel", "SendMessages"] },
                    { id: interaction.client.user.id, allow: ["ViewChannel", "SendMessages"] },
                    { id: interaction.user.id, allow: ["ViewChannel", "SendMessages"] },
                ];

                await createChannel("🛒・logs-vendas", ChannelType.GuildText, categoryStaff.id, staffPermissions, `**Canal de logs de vendas**\n\nNeste canal, você pode ver todas as logs de vendas que ocorreram no servidor.`);
                await createChannel("❓・dicas", ChannelType.GuildText, categoryStaff.id, staffPermissions, `[ https://discord.gg/9VAfMk44Ju ] \n\nObrigado por comprar conosco, volte sempre!\n\n📚 | Preparativos!\n🔧 1 - Arrume a sua conta do discord;\n- Utilize o "!" no início do nome,\nEx: "! pw"\n\n- Coloque uma status chamativo na sua conta,\nEx: "Nitro Gift Por 12.00R$ BIO"\n\nMas caso venha ser um que já existe, tente se destacar mais do que a outra.\n\n🏴󠁧   󠁢󠁳󠁣󠁴󠁿  | Configurações Loja\n\n🔧 1 - Organize os canais;\n\n- Tente sempre usar algo mais simples e clean,\nAlgo não tão morto mas nada exagerado.\n\n- Não utilize fontes,\nOpte sempre para não utilizar fontes em seus canais, pois isto dificulta\ncom que o seu futuro cliente veja oque está escrito\n\n🔧 2 - Arte Visual\n\n- Use uma arte clean e que destaque o nome da loja\nSendo o nome o foco da arte\n\n🔧 3 - Canais Principais\n\n- Drops\nSempre deixe o seu servidor ativo utilizando este canal,\nCaso drope algum produto e alguém pegue e outra pessoa também queria, isto irá causar\num desejo no cliente, fazendo-o comprar o produto que vc soltou.\n\n- Logs Entregas\n\nIsto serve para que mostre o produto que alguma pessoa comprou,\npara que alguém não pense que o seu servidor seja falso.\n\n🔧 4 - Sorteios\n\n- Faça um sorteio chamativo com o requisito de que tenha que convidar uma pessoa\nIsto irá fazer uma disputa na sua loja, de quem convida mais e etc.\n\n🔧 5 - Promoções\n\n- Tente sempre fazer alguma promoção especial\nEx: Compre 3 e leve 1 de graça!\n\n🔧 6 - Produto\n\n- Procure por ter um produto fixo na sua loja, algo que venda bastante\nE que seus clientes sempre peça estoque daquele produto`);
                await createChannel("📂・logs-auth", ChannelType.GuildText, categoryStaff.id, staffPermissions, `**Canal de logs de auth**\n\nNeste canal, você deve configurar o seu auth para enviar logs aqui.`);
                await createChannel("📂・logs-carrinho", ChannelType.GuildText, categoryStaff.id, staffPermissions, `**Canal de logs de carrinho**\n\nNeste canal, você pode ver todas as logs de carrinho que ocorreram no servidor.`);

                i.editReply({
                    content: "",
                    embeds: [
                        new EmbedBuilder()
                            .setDescription(`✅ Todos os Canais e Cargos foram criados com sucesso! \n\n 🛒 Suporte em: [Loja Zeus](https://discord.gg/9VAfMk44Ju)`)
                            .setColor("#2b2d31")
                    ]
                });
            } else if (i.customId === 'cancel') {
                await i.update({ content: `O comando foi cancelado.`, embeds: [], components: [], ephemeral: true });
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                interaction.editReply({ content: `O tempo para responder acabou, o comando foi cancelado.`, embeds: [], components: [], ephemeral: true });
            }
        });
    }

module.exports = {
    CreateStore
}