const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson");


async function ConfigChannels(interaction, client) {

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("logpedidos")
                .setLabel('Definir canal de logs de pedidos')
                .setEmoji(`1262295420181286963`)
                .setStyle(2),

            new ButtonBuilder()
                .setCustomId("eventbuy")
                .setLabel('Definir canal de logs compras')
                .setEmoji(`1262295420181286963`)
                .setStyle(2),
        )
    const row3 = new ActionRowBuilder()
        .addComponents(
             new ButtonBuilder()
                .setCustomId("boasvindascoole")
                .setLabel('Definir canal de logs moderação')
                .setEmoji(`1262295420181286963`)
                .setStyle(2)
                .setDisabled(false),

            new ButtonBuilder()
                .setCustomId("feedback")
                .setLabel('Definir canal de logs de feedback')
                .setEmoji(`1262295420181286963`)
                .setStyle(2),

            new ButtonBuilder()
                .setCustomId("systemlogs")
                .setLabel('Definir canal de logs do sistema')
                .setEmoji(`1262295420181286963`)
                .setStyle(2),
            new ButtonBuilder()
                .setCustomId("logentrada")
                .setLabel('Definir canal de logs de entradas')
                .setEmoji(`1262295420181286963`)
                .setStyle(2),
        )

        /* const row5 = new ActionRowBuilder()
        .addComponents(

            new ButtonBuilder()
                .setCustomId("logsaida")
                .setLabel('Definir canal de logs de saídas')
                .setEmoji(`1191798275616018432`)
                .setStyle(1)
                .setDisabled(true),
        ) */

        const row6 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("logmensagem")
                .setLabel('Definir canal de logs de mensagens')
                .setEmoji(`1262545769001390222`)
                .setStyle(1)
                .setDisabled(false),

            new ButtonBuilder()
                .setCustomId("trafegocall")
                .setLabel('Definir canal de logs de tráfego de call')
                .setEmoji(`1262545284341174294`)
                .setStyle(1)
                .setDisabled(false), 

                new ButtonBuilder()
                .setCustomId("voltar2")
                .setEmoji(`1262295432130723842`)
                .setStyle(2)
        )

   

    const embed = new EmbedBuilder()

        .setTitle('Configurar Canais')
        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc': configuracao.get('Cores.Principal')}`)
        .setDescription(`-  você acessou minha aba de configurações de canais, verifique **abaixo os canais** que não **estiverem configurados.** Configure urgentemente para **evitar bugs no bot.**`)
        .setFields(
            {
                name: `**Canal de log de pedidos:**`,
                value: `${configuracao.get(`ConfigChannels.logpedidos`) == null ? `\`🔴 Não definido\`` : `<#${configuracao.get(`ConfigChannels.logpedidos`)}>`}`,
                inline: true
            },
            {
                name: `**Canal de log compras:**`,
                value: `${configuracao.get(`ConfigChannels.eventbuy`) == null ? `\`🔴 Não definido\`` : `<#${configuracao.get(`ConfigChannels.eventbuy`)}>`}`,
                inline: true
            },
            {
                name: `**Canal de logs do sistema:**`,
                value: `${configuracao.get(`ConfigChannels.systemlogs`) == null ? `\`🔴 Não definido\`` : `<#${configuracao.get(`ConfigChannels.systemlogs`)}>`}`,
                inline: true
            },
            {
                name: `**Canal de feedback:**`,
                value: `${configuracao.get(`ConfigChannels.feedback`) == null ? `\`🔴 Não definido\`` : `<#${configuracao.get(`ConfigChannels.feedback`)}>`}`,
                inline: true
            },
            {
                name: `**Canal de logs de entradas:**`,
                value: `${configuracao.get(`ConfigChannels.entradas`) == null ? `\`🔴 Não definido\`` : `<#${configuracao.get(`ConfigChannels.entradas`)}>`}`,
                inline: true
            },
            {
                name: `**Canal de logs moderação:**`,
                value: `${configuracao.get(`ConfigChannels.boasvindascoole`) == null ? `\`🔴 Não definido\`` : `<#${configuracao.get(`ConfigChannels.boasvindascoole`)}>`}`,
                inline: true
            }
        )
/* **Canal de logs de saídas:** ${configuracao.get(`ConfigChannels.saídas`) == null ? `\`🔴 Não definido\`` : `<#${configuracao.get(`ConfigChannels.saídas`)}>`}
**Canal de logs de mensagens:** ${configuracao.get(`ConfigChannels.mensagens`) == null ? `\`🔴 Não definido\`` : `<#${configuracao.get(`ConfigChannels.mensagens`)}>`}
**Canal de logs de tráfego em call:** ${configuracao.get(`ConfigChannels.tráfego`) == null ? `\`🔴 Não definido\`` : `<#${configuracao.get(`ConfigChannels.tráfego`)}>`}
*/
        .setFooter(
            { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
        )
        .setTimestamp()


    if (interaction.message == undefined) {
        interaction.reply({ content: ``, embeds: [embed], components: [row2, row3, /* row5, */ row6] })
    } else {
        interaction.update({ content: ``, embeds: [embed], components: [row2, row3, /* row5, */ row6] })
    }



}


async function ConfigRoles(interaction, client) {


    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("definircargoadm")
                .setLabel('Definir cargo de Administrador')
                .setEmoji(`1178080366871973958`)
                .setStyle(2),

            new ButtonBuilder()
                .setCustomId("definircargosup")
                .setLabel('Definir cargo de Suporte')
                .setEmoji(`1178133970634948700`)
                .setStyle(2),
        )
    const row3 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("roleclienteease")
                .setLabel('Definir cargo de Cliente')
                .setEmoji(`1178090605734273026`)
                .setStyle(2),

            new ButtonBuilder()
                .setCustomId("rolememberok")
                .setLabel('Definir cargo de membro')
                .setEmoji(`1178090724105920594`)
                .setStyle(2),
        )
    const row4 = new ActionRowBuilder()
        .addComponents(

            new ButtonBuilder()
                .setCustomId("voltar2")
                .setEmoji(`1262295432130723842`)
                .setStyle(2)
        )


    const embed = new EmbedBuilder()

        .setTitle('Configurar cargos')
        .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc': configuracao.get('Cores.Principal')}`)
        .setDescription(`-  você acessou minha aba de configurações de cargos, verifique **abaixo os cargos** que não **estiverem configurados.** Configure urgentemente para **evitar bugs no bot.**`)
        .addFields(
            {
                name: `**Cargo de Administrador:**`,
                value: `${configuracao.get(`ConfigRoles.cargoadm`) == null ? `\`🔴 Não definido\`` : `<@&${configuracao.get(`ConfigRoles.cargoadm`)}>`}`,
                inline: true
            },
            {
                name: `**Cargo de Suporte:**`,
                value: `${configuracao.get(`ConfigRoles.cargosup`) == null ? `\`🔴 Não definido\`` : `<@&${configuracao.get(`ConfigRoles.cargosup`)}>`}`,
                inline: true
            },
            {
                name: `**Cargo de Cliente:**`,
                value: `${configuracao.get(`ConfigRoles.cargoCliente`) == null ? `\`🔴 Não definido\`` : `<@&${configuracao.get(`ConfigRoles.cargoCliente`)}>`}`,
                inline: true
            },
            {
                name: `**Cargo de Membro:**`,
                value: `${configuracao.get(`ConfigRoles.cargomembro`) == null ? `\`🔴 Não definido\`` : `<@&${configuracao.get(`ConfigRoles.cargomembro`)}>`}`,
                inline: true
            }
        )


    if (interaction.message == undefined) {
        interaction.reply({ content: ``, embeds: [embed], components: [row2, row3, row4] })
    } else {
        interaction.update({ content: ``, embeds: [embed], components: [row2, row3, row4] })
    }

}


module.exports = {
    ConfigRoles,
    ConfigChannels
}
