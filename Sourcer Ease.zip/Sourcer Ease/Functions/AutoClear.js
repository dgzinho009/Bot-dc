const { RoleSelectMenuBuilder, EmbedBuilder, InteractionType, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js")
const Discord = require("discord.js")
const { JsonDatabase } = require('wio.db');
const { relikia } = require("../DataBaseJson");

async function AutoClear(interaction, client) {
  const canalautoclear = await relikia.get("autoclear.channel");
  const tempoclear = await relikia.get("autoclear.time")



  interaction.update({
    content: '',
    embeds: [
      new Discord.EmbedBuilder()
    .setTitle(`Configurando \`AutoClear\``)
    .setDescription(` você acessou a aba de **AutoClear**, suas **informações** mais os **botões de configurações** estão aqui em baixo. **Configure tudo!**`)
    .addFields(
      {
        name: `🚪 | Canal AutoClear:`,
        value: canalautoclear ? `<#${canalautoclear}>` : 'Nenhum canal selecionado',
        inline: true
      },
      {
        name: `⏰ | Tempo AutoClear:`,
        value: `${tempoclear} segundos`,
        inline: true
      },
    )
    ],
    components: [
      new Discord.ActionRowBuilder()
      .addComponents(
          new Discord.ButtonBuilder()
              .setCustomId(`autoclearcanal`)
              .setLabel("Configurar Canal")
              .setEmoji("1262295420181286963")
              .setStyle(2),
          new Discord.ButtonBuilder()
              .setCustomId(`autocleartempo`)
              .setLabel("Configurar Tempo")
              .setEmoji("1207761646152458351")
              .setStyle(2),
      ),
      new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
        .setCustomId('iniciarautoclear')
        .setLabel('Ligar AutoClear')
        .setEmoji(`1248749835109011468`)
        .setStyle(3),
        new Discord.ButtonBuilder()
        .setCustomId('pararautoclear')
        .setLabel('Desligar AutoClear')
        .setEmoji(`1248749849466376333`)
        .setStyle(4),
        new Discord.ButtonBuilder()
          .setCustomId('voltarautofrcabuloso')
          .setEmoji('1237422652050899084')
          .setStyle(2)
      )
    ]
  });
}

module.exports = {
  AutoClear
};
