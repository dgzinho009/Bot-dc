const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { relikia, produtos, configuracao } = require("../DataBaseJson");
const startTime = Date.now();
const maxMemory = 100;
const usedMemory = process.memoryUsage().heapUsed / 1024 / 1024;
const memoryUsagePercentage = (usedMemory / maxMemory) * 100;
const roundedPercentage = Math.min(100, Math.round(memoryUsagePercentage));


async function autorole(interaction, client) {
  const userid = interaction.user.id;
  const roles = await relikia.get("automod.autorole") || [];
  let kkk = roles.map((a) => {return `<@&${a}>`})
  .join("\n");
  if(roles.length <= 0) {
      kkk = `Nenhum Cargo Definido!`;
  }
  
  await interaction.update({
      embeds:[
          new EmbedBuilder()
          .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL()})
          .setTitle("Cargos Automáticos:")
          .setDescription(`${kkk}`)
          .setColor("#2b2d31")
          .setThumbnail(interaction.client.user.displayAvatarURL())
          .setFooter({text:`${interaction.guild.name}`, iconURL: interaction.guild.iconURL()})
          .setTimestamp()
      ],
      components:[
          new ActionRowBuilder()
          .addComponents(
              new ButtonBuilder()
              .setCustomId(`${userid}_addcargoentrar`)
              .setLabel("Adicionar Cargo Ao Entrar")
              .setEmoji("1237422815473434644")
              .setStyle(2),
              new ButtonBuilder()
              .setCustomId(`${userid}_resetautoroles`)
              .setStyle(1)
              .setLabel(`Resetar`)
              .setEmoji("🔁"),
              new ButtonBuilder()
              .setCustomId(`voltarautofrcabuloso`)
              .setStyle(2)
              .setEmoji("1237422652050899084")
          )
      ]
  })
}


async function mensagemautoedit() {
  const userid = interaction.user.id;
  const mensagem = await relikia.get("automod.mensagem_auto");
  const status = mensagem.system ? "`Ativado!`" : "`Desativado!`";
  let ok = mensagem.mensagem.map((a, index) => {return `(\`${index + 1}\`) - ${a.desc}`})
  .join("\n");
  if(mensagem.mensagem.length <= 0 ) {
      ok = "Nenhuma mensagem definida!";
  };
  await interaction.message.edit({
    embeds:[
      new EmbedBuilder()
      .setTitle("Mensagens Automáticas")
      .addFields(
        {name: `**Mensagens Automaticas:**`, value: `${status}`, incline: true}
      )
      .setDescription(`➡️** | Mensagens Automaticas:**\n${ok}`)
      .setColor("#2b2d31")
      .setThumbnail(interaction.client.user.displayAvatarURL())
      .setTimestamp()
      .setFooter({text:`${interaction.guild.name}`, iconURL: interaction.guild.iconURL()})
      .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL()})
  ],
      components:[
          new ActionRowBuilder()
          .addComponents(
              new ButtonBuilder()
              .setCustomId(`${userid}_criarmsgauto`)
              .setLabel("Criar Mensagem Automática")
              .setEmoji("<:mais:1237422815473434644>")
              .setStyle(1),
              new ButtonBuilder()
              .setCustomId(`${userid}_removermsgauto`)
              .setLabel("Remover Mensagem Automática")
              .setEmoji("<:menos2:1262295420181286963> ")
              .setStyle(1),
          ),
          new ActionRowBuilder()
          .addComponents(
              new ButtonBuilder()
              .setCustomId(`onoffmsgauto`)
              .setLabel("Ativar/Desativar Mensagens")
              .setEmoji("<:airbots:1251227294362505307>")
              .setStyle(2),
              new ButtonBuilder()
              .setCustomId(`voltarautofrcabuloso`)
              .setStyle(2)
              .setEmoji("⬅")
          )
      ]
  })
}

async function mensagemauto(interaction, client) {
  const userid = interaction.user.id;
  const mensagem = await relikia.get("automod.mensagem_auto");
  const status = mensagem.system ? "`Ativado`" : "`Desativado`";
  let ok = mensagem.mensagem.map((a, index) => {return `(\`${index + 1}\`) - ${a.desc}`})
  .join("\n");
  if(mensagem.mensagem.length <= 0 ) {
      ok = "Nenhuma mensagem definida!";
  };
  await interaction.update({
      embeds:[
          new EmbedBuilder()
          .setTitle("Mensagens Automáticas")
        
          .addFields(
            {name: `**Mensagens Automaticas:**`, value: `${status}`, incline: true}
          )
          .setDescription(`➡️** | Mensagens Automaticas:**\n${ok}`)
          .setColor("#2b2d31")
          .setThumbnail(interaction.client.user.displayAvatarURL())
          .setTimestamp()
          .setFooter({text:`${interaction.guild.name}`, iconURL: interaction.guild.iconURL()})
          .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL()})
      ],
      components:[
        new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
          .setCustomId(`${userid}_criarmsgauto`)
          .setLabel("Criar Mensagem Automática")
          .setEmoji("<:mais:1237422815473434644>")
          .setStyle(1),
          new ButtonBuilder()
          .setCustomId(`${userid}_removermsgauto`)
          .setLabel("Remover Mensagem Automática")
          .setEmoji("<:menos2:1262295420181286963> ")
          .setStyle(1),
      ),
        new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId(`onoffmsgauto`)
            .setLabel("Ativar/Desativar Mensagens")
            .setEmoji("<:airbots:1251227294362505307>")
            .setStyle(2),
            new ButtonBuilder()
            .setCustomId(`voltarautofrcabuloso`)
            .setStyle(2)
            .setEmoji("⬅")
        )
      ]
  })
}


async function PainelMember(interaction, client) {
}

async function PainelPrincipal(interaction, client) {

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("paineladmin")
        .setLabel('Painel Principal')
        .setEmoji(`1262346147893219358`)
        .setStyle(1)
        .setDisabled(false),
    )

  if (interaction.message == undefined) {
    interaction.reply({ content: `Seja muito **bem-vindo** ao meu painel`, components: [row2,], embeds: [], ephemeral: true })
  } else {
    interaction.update({ content: `Selecione sua opção abaixo:`, components: [row2,], embeds: [], ephemeral: true })
  }
}



async function Painel(interaction, client) {

  const embed = new EmbedBuilder()
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
    .setAuthor({ name: `${client.user.username}`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
    .setDescription(`Olá ${interaction.user}, Seja muito **bem-vindo** ao meu painel de configuração completo. Você é totalmente permitido para alterar qualquer coisa do nosso sistema de gerenciamento, **configure tudo** principalmente as **logs** para evitar todo tipo de bug.`)
    .setThumbnail(interaction.user.avatarURL({ dynamic: true }))

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("painelconfigvendas")
        .setLabel('Funções Principais')
        .setEmoji(`1237422650205405235`)
        .setStyle(1)
        .setDisabled(false),
      new ButtonBuilder()
        .setCustomId("painelmod")
        .setLabel('Moderação')
        .setEmoji(`1239712553496612975`)
        .setStyle(2)
        .setDisabled(false),
      

    )

  const row4 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("painelconfigat")
        .setLabel('Funções Automatícas')
        .setEmoji(`1240427213203968102`)
        .setStyle(2)
        .setDisabled(false),
        
        new ButtonBuilder()
        .setCustomId("painelconfigticket")
        .setLabel('Ticket Painel')
        .setEmoji(`1248749270014627883`)
        .setStyle(2)
        .setDisabled(false),

      new ButtonBuilder()
       .setCustomId("sistemadebackupconfig")
       .setLabel('Security')
       .setEmoji(`1249217113281925212`)
       .setStyle(2)
       .setDisabled(false),

    )
  const row5 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
      .setCustomId("gerenciarconfigs")
      .setLabel('Configurar Pagamentos')
      .setStyle(2)
      .setEmoji(`1262340770522730588`)
      .setDisabled(false),
      new ButtonBuilder()
        .setCustomId("painelpersonalizar")
        .setLabel('Customizar')
        .setEmoji(`1178066208835252266`)
        .setStyle(1)
        .setDisabled(false),
      new ButtonBuilder()
        .setCustomId("permsbotfrcabuloso")
        .setLabel('Configurar Permissões')
        .setEmoji(`1248749863022235790`)
        .setStyle(2)
        .setDisabled(false),
      new ButtonBuilder()
        .setCustomId("voltarpainelprincipal")
        .setEmoji(`1262295432130723842`)
        .setStyle(2)
        .setDisabled(false),
    )


  if (interaction.message == undefined) {
    interaction.reply({ content: ``, components: [row2, row4, row5], embeds: [embed], ephemeral: true })
  } else {
    interaction.update({ content: ``, components: [row2, row4, row5], embeds: [embed], ephemeral: true })
  }
}

async function Gerenciar2(interaction, client) {

  const ggg = produtos.valueArray();


  const embed = new EmbedBuilder()
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
    .setTitle(`Configure sua loja`)
    .setDescription(`Olá **${interaction.user.username}**, escolha o que deseja fazer em sua loja.`)
    .addFields(
      { name: `**Total de produtos fornecidos**`, value: `${ggg.length}`, inline: true },
    )
    .setFooter(
      { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
    )
    .setTimestamp()

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("criarrrr")
        .setLabel('Criar um produto')
        .setEmoji(`1262295405320867942`)
        .setStyle(2),

      new ButtonBuilder()
        .setCustomId("gerenciarotemae")
        .setLabel('Editar Produto')
        .setEmoji(`1262295428070903829`)
        .setStyle(2),

      new ButtonBuilder()
        .setCustomId("gerenciarposicao")
        .setLabel('Alterar Posições')
        .setEmoji(`1262295428070903829`)
        .setStyle(2),

    )

  const row3 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("requestImage")
        .setLabel('Alterar QR-CODE da loja')
        .setEmoji(`1262338488947183717`)
        .setStyle(2),
      new ButtonBuilder()
        .setCustomId("criarlojadessecrlh")
        .setLabel('Criar Loja')
        .setEmoji(`1262295410177740892`)
        .setStyle(2),
      // new ButtonBuilder()
      //   .setCustomId("addemojisnessaporra")
      //   .setLabel('Adicionar Emojis ( Um click )')
      //   .setEmoji(`1240455964436467743`)
      //   .setStyle(2),
      new ButtonBuilder()
        .setCustomId("voltar00")
        .setEmoji(`1262295432130723842`)
        .setStyle(2)
    )



  await interaction.update({ embeds: [embed], components: [row2, row3], content: `` })



}

module.exports = {
  PainelPrincipal,
  Painel,
  Gerenciar2,
  mensagemauto,
  mensagemautoedit,
  autorole,
  PainelMember
}
