const { ActionRowBuilder, EmbedBuilder, ButtonBuilder } = require('discord.js');
const { configuracao, estatisticas, } = require('../DataBaseJson');
const axios = require('axios');
const { JsonDatabase } = require('wio.db');


async function Varredura(client) {
    
    if (configuracao.get('ConfigChannels.systemlogs') == null) return;
    if (configuracao.get('pagamentos.MpAPI') == null) return;

    const embed3 = new EmbedBuilder()
        .setColor('#1c44ff')
        .setTitle(`Anti-Fraude`)
        .setDescription(`O bot da Braga Store está realizando uma varredura nos pagamentos para verificar a existência de quaisquer reembolsos suspeitos.`)
        .setFooter({ iconURL: `https://media.discordapp.net/attachments/1258998310048501801/1259003598075985921/Logo_zeustm.jpg?ex=668eb738&is=668d65b8&hm=f2f16e82a3b488ccf6348968a6ceb52dd119a76046fe6165135fabacecf6ccd2&=&format=webp&width=559&height=559`, text: `Sistema Anti-Fraude - Zeus.` })
        .setTimestamp();

    const row222 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('asSs')
                .setLabel('Mensagem do Sistema')
                .setStyle(2)
                .setDisabled(true)
        );

    const channel = await client.channels.cache.get(configuracao.get('ConfigChannels.systemlogs'));
    if(channel) await channel.send({ components: [row222], embeds: [embed3] });

    try {
        if(!await configuracao.get("pagamentoMpAPI")) return;
        const refundResponse = await axios.get('https://api.mercadopago.com/v1/payments/search', {
            params: {
                'access_token': `${configuracao.get('pagamentos.MpAPI')}`,
                'status': 'refunded'
            }
        });
    
        const dd = refundResponse.data.results;
    
     
        const refounds = new JsonDatabase({
            databasePath: "./DataBaseJson/refounds.json"
          });
    
    
          for (const element of dd) {
            const isRefunded = await refounds.get(`${element.id}`);
        
            if (!isRefunded) {
                await refounds.set(`${element.id}`, `Reembolsado`);
        
                let id = await element.external_reference
                if (element.external_reference == null) {
                    id = 'Não encontrado'
                }
        
                const embed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle(` Reembolso Detectado`)
                    .setDescription(`Um reembolso foi detectado no sistema de pagamentos.`)
                    .addFields(
                        { name: `**ID do pagamento**`, value: `\`${element.id}\``, inline: true },
                        { name: `**ID do usuário**`, value: `\`${id}\``, inline: true },
                        { name: `**Valor**`, value: `\`${element.transaction_amount}\``, inline: true },
                        { name: `**Data**`, value: `<t:${Math.ceil(Date.now() / 1000)}:R>`, inline: true },
                        { name: `**Status**`, value: `\`${element.status}\``, inline: true },
                        { name: `**Tipo de pagamento**`, value: `\`${element.payment_type_id}\``, inline: true },
                        { name: `**Tipo de operação**`, value: `\`${element.operation_type}\``, inline: true },
                    );
        
                try {
                    if(channel) await channel.send({ components: [row222], embeds: [embed] });
                } catch (error) {
                    console.error('Erro ao enviar a mensagem:', error);
                }
        
                const estatisticasData = estatisticas.fetchAll();
                for (const element2 of estatisticasData) {
                    if (element2.data.idpagamento === element.id) {
                        estatisticas.delete(element2.ID);
                    }
                }
            }
          }
    } catch {

    }
    }
    


module.exports = {
    Varredura
};
