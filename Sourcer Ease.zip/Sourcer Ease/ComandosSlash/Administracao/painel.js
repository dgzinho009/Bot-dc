const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder,ButtonBuilder } = require("discord.js");
const startTime = Date.now();
const fs = require('fs');
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const maxMemory = 100;
const usedMemory = process.memoryUsage().heapUsed / 1024 / 1024;
const memoryUsagePercentage = (usedMemory / maxMemory) * 100;
const roundedPercentage = Math.min(100, Math.round(memoryUsagePercentage));
const { Painel, PainelPrincipal } = require("../../Functions/Painel.js");
const { JsonDatabase } = require("wio.db");
const dbPerms = new JsonDatabase({ databasePath: "./DataBaseJson/perm.json" });

module.exports = {
  name: "painel",
  description: "Execute o comando de configurações do seu bot",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction, message) => {
    
    if (!dbPerms.has(interaction.user.id)) {
        if (interaction.user.id !== config.owner) {
            await interaction.reply({
                content: `❌ | Você não tem permissão para usar este comando.`,
                ephemeral: true
            });
            return;
        }
    }
    
    PainelPrincipal(interaction, client)
  }
}
