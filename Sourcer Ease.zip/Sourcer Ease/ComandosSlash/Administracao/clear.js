const { ApplicationCommandType, EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
    name: "cls",
    description: "Apagar mensagens de um canal",
    type: ApplicationCommandType.ChatInput,

    options: [
        {
            name: "quanty",
            description: "Quantas mensagens você deseja apagar?",
            type: 4,
            required: false,
            minValue: 1,
            maxValue: 1000
        },
        {
            name: "user",
            description: "Usuário específico para apagar mensagens",
            type: 6,
            required: false
        },
        {
            name: "especify",
            description: "Mensagem específica para apagar",
            type: 3,
            required: false
        }
    ],

    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            const noPermissionEmbed = new EmbedBuilder()
                .setDescription("Você não tem permissão para apagar mensagens!")
                .setColor("Red")
                .setTimestamp();

            return interaction.reply({ embeds: [noPermissionEmbed], ephemeral: true });
        }

        const quanty = interaction.options.getInteger("quanty");
        const user = interaction.options.getUser("user");
        const mensagemEspecifica = interaction.options.getString("especify");
        const canal = interaction.channel;

        try {
            if (quanty && user) {
                const messages = await canal.messages.fetch({ limit: quanty });
                const messagesToDelete = messages.filter(message => message.author.id === user.id);
                await Promise.all(messagesToDelete.map(message => message.delete()));
                
                const successEmbed = new EmbedBuilder()
                    .setTitle("🐱‍🏍 | Mensagens Apagadas")
                    .setDescription(`Foram apagadas com sucesso \`${messagesToDelete.size}\` mensagens de ${user.tag}!`)
                    .setColor("#2b2d31")

                return interaction.reply({ embeds: [successEmbed], ephemeral: true });
            }

            if (quanty) {
                const messages = await canal.bulkDelete(quanty, true);
                
                const successEmbed = new EmbedBuilder()
                    .setTitle("🐱‍🏍 | Mensagens Apagadas")
                    .setDescription(`Foram apagadas com sucesso \`${messages.size}\` mensagens do canal!`)
                    .setColor("#2b2d31")

                return interaction.reply({ embeds: [successEmbed], ephemeral: true });
            }

            if (user) {
                const messages = await canal.messages.fetch({ limit: 100 });
                const messagesToDelete = messages.filter(message => message.author.id === user.id);
                await Promise.all(messagesToDelete.map(message => message.delete()));
                
                const successEmbed = new EmbedBuilder()
                    .setTitle("🐱‍🏍 | Mensagens Apagadas")
                    .setDescription(`Foram apagadas com sucesso mensagens de ${user.tag}!`)
                    .setColor("#2b2d31")

                return interaction.reply({ embeds: [successEmbed], ephemeral: true });
            }

            if (mensagemEspecifica) {
                const messages = await canal.messages.fetch({ limit: 100 });
                const messagesToDelete = messages.filter(message => message.content.includes(mensagemEspecifica));
                await Promise.all(messagesToDelete.map(message => message.delete()));
                
                const successEmbed = new EmbedBuilder()
                    .setTitle("🐱‍🏍 | Mensagens Apagadas")
                    .setDescription(`Foram apagadas com sucesso mensagens contendo "${mensagemEspecifica}"!`)
                    .setColor("#2b2d31")

                return interaction.reply({ embeds: [successEmbed], ephemeral: true });
            }

            const messages = await canal.bulkDelete(100, true);
            
            const successEmbed = new EmbedBuilder()
                .setTitle("🐱‍🏍 | Mensagens Apagadas")
                .setDescription(`Foram apagadas com sucesso ${messages.size} mensagens do canal!`)
                .setColor("#2b2d31")

            return interaction.reply({ embeds: [successEmbed], ephemeral: true });

        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setTitle("❌ | Erro ao Apagar Mensagens")
                .setDescription(`Ocorreu uma falha ao tentar apagar as mensagens: ${error.message}`)
                .setColor("#2b2d31")

            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};
